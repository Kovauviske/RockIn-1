# Slave_Traders
Slave Traders code for Altis Life - Arma 3
coded by @Foamy
http://www.therevolutiongaming.com/
